package deliege.adrien.cms

import com.mysql.cj.log.Log
import deliege.adrien.cms.tpl.Article
import deliege.adrien.cms.tpl.ConnectionPool
import deliege.adrien.cms.tpl.IndexContext
import freemarker.cache.ClassTemplateLoader
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.freemarker.FreeMarker
import io.ktor.freemarker.FreeMarkerContent
import io.ktor.http.HttpStatusCode
import io.ktor.response.respond
import io.ktor.routing.get
import io.ktor.routing.routing
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import java.sql.DriverManager

//data class User(val name: String, val age: Int)

class App

fun main()
{
    //val connection = DriverManager.getConnection("jdbc:mysql://localhost:8889/kotlin?serverTimezone=UTC", "root", "root")
    val pool = ConnectionPool("jdbc:mysql://localhost:8889/kotlin?serverTimezone=UTC", "root", "root")

    embeddedServer(Netty, 8080) {
        install(FreeMarker) {
            templateLoader = ClassTemplateLoader(App::class.java.classLoader, "templates")
        }

        routing {
            get("/article/{id}") {
                val id = call.parameters["id"]!!.toInt()

                pool.useConnection { connection ->
                    connection.prepareStatement("SELECT * FROM articles WHERE id = ?").use {stmt ->
                        stmt.setInt(1, id)

                        stmt.executeQuery().use {result ->
                            if (result.next())
                            {
                                val article = Article(result.getInt("id"), result.getString("title"), result.getString("text"))
                                call.respond(FreeMarkerContent("article.ftl", article, "e"))
                            } else {
                                call.respond(HttpStatusCode.NotFound)
                            }
                        }
                    }
                }
            }

            get("/") {
                val list = ArrayList<Article>()

                pool.useConnection { connection ->
                    connection.prepareStatement("SELECT id, title FROM articles").use {stmt ->
                        val results = stmt.executeQuery().use {results ->
                            while (results.next())
                            {
                                list += Article(results.getInt("id"), results.getString("title"), null)
                            }
                        }
                    }
                }






                val context = IndexContext(list)
                call.respond(FreeMarkerContent("index.ftl", context, "e"))
            }

        }
    }.start(wait = true)
}