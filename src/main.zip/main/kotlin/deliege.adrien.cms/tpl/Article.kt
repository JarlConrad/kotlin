package deliege.adrien.cms.tpl

data class Article(
    val id: Int,
    val title: String,
    val text: String?
)