package deliege.adrien.cms.tpl

data class IndexContext(
    val list: List<Article>
)
